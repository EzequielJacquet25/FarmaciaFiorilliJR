# Design System Strategy: The Clinical Atelier

## 1. Overview & Creative North Star
**The Creative North Star: "Precision Serenity"**

This design system moves away from the sterile, rigid grids of traditional healthcare platforms and toward a "Clinical Atelier" aesthetic. It balances the exacting precision of pharmaceutical compounding with a calming, high-end editorial experience. 

We break the "template" look by utilizing **intentional asymmetry** and **tonal layering**. Large-scale typography creates an authoritative voice, while generous white space (breathing room) ensures the user never feels overwhelmed. The goal is to make the patient feel they are entering a modern laboratory that is as much about personalized care as it is about scientific rigor.

---

## 2. Colors: Tonal Depth & The "No-Line" Rule
The palette is rooted in medical trust but executed with sophisticated nuance. We move beyond flat blocks of color to create an environment that feels tactile and high-end.

*   **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Structural boundaries must be defined solely through background color shifts. For example, a `surface-container-low` section should sit directly against a `surface` background to create a soft, natural edge.
*   **Surface Hierarchy:** We treat the UI as a series of physical layers.
    *   **Base:** `surface` (#f8fafa) for the primary canvas.
    *   **Low Elevation:** `surface-container-low` (#f2f4f4) for secondary content blocks.
    *   **High Focus:** `surface-container-highest` (#e1e3e3) for interactive utility panels.
*   **The "Glass & Gradient" Rule:** To elevate the "magistral" (hand-crafted) nature of the pharmacy, use Glassmorphism for floating navigation and modals. Utilize a `surface-container-lowest` color at 70% opacity with a `24px` backdrop blur.
*   **Signature Textures:** For Hero backgrounds and Primary CTAs, use a subtle linear gradient from `primary` (#004275) to `primary-container` (#005a9c) at a 135-degree angle. This adds "visual soul" and depth that a flat hex code cannot achieve.

---

## 3. Typography: The Editorial Voice
We use **Inter** to bridge the gap between technical readability and modern elegance.

*   **Display & Headlines:** Use `display-lg` (3.5rem) for high-impact value propositions. Apply tight letter-spacing (-0.02em) to headlines to create a "compact" and authoritative editorial look.
*   **The Hierarchy of Trust:** 
    *   **Headlines (`headline-lg`):** Use for section titles to command attention.
    *   **Titles (`title-lg`):** Reserved for product names or compounding categories.
    *   **Body (`body-lg`):** Set at `1rem` with a generous line-height (1.6) to ensure maximum accessibility for patients.
*   **Labeling:** Use `label-md` in all-caps with 0.05em letter-spacing for category tags (e.g., "DERMATOLOGY", "PEDIATRICS") to give a scientific, indexed feel.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "digital." We use ambient light and layering to imply depth.

*   **The Layering Principle:** Depth is achieved by "stacking." Place a `surface-container-lowest` card on a `surface-container-low` background. The slight shift in brightness creates a soft, natural lift.
*   **Ambient Shadows:** If a card must float (e.g., a prescription upload button), use an extra-diffused shadow: `offset-y: 8px, blur: 32px, color: rgba(0, 72, 127, 0.06)`. Note the use of a tinted shadow (Primary Blue) rather than grey.
*   **The "Ghost Border" Fallback:** For input fields or necessary boundaries, use a "Ghost Border": the `outline-variant` token at 15% opacity. It should be felt, not seen.
*   **Glassmorphism:** Use `surface-tint` sparingly on top of glass layers to create a "tinted lens" effect for specialized notifications.

---

## 5. Components: Precision Elements

### Buttons & Interaction
*   **Primary CTA:** Uses the `primary` to `primary-container` gradient. Shape: `xl` roundedness (1.5rem). No shadow; instead, a slight scale-up (1.02x) on hover.
*   **Secondary (Sage):** Uses `secondary-container` (#c9eea9) with `on-secondary-container` (#4e6d36) text. This is for low-stress actions like "Learn More."
*   **Tertiary:** Ghost style. No background, `primary` text, `sm` (0.25rem) bottom-border only on hover.

### Cards & Compound Lists
*   **The Content Card:** Forbid divider lines. Separate "Ingredients" from "Instructions" using a 24px vertical gap and a background shift to `surface-container-low`.
*   **Input Fields:** Use a `surface-container-highest` background with `none` border. On focus, transition the background to `surface-container-lowest` and add a 1px `primary` ghost border (20% opacity).

### Specialized Pharmacy Components
*   **Compounding Status Tracker:** A vertical, non-linear stepper using `secondary` (Sage) to indicate progress. Each step uses a `surface-container-low` rounded box.
*   **Dosage Chips:** Use `secondary-fixed` (#c9eea9) for dosage amounts. The soft green reinforces the "soothing" nature of the medicine.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts (e.g., text on the left, image overlapping the container edge on the right) to create a custom, high-end feel.
*   **Do** prioritize high-quality, macro photography of clear glass, botanical extracts, and clean laboratory environments.
*   **Do** use "Surface-Container-Lowest" for cards to make them pop against "Surface" backgrounds.

### Don't
*   **Don't** use 100% black text. Always use `on-surface` (#191c1d) for a softer, more professional contrast.
*   **Don't** use standard "Success" greens. Always use the `secondary` Sage Green (#486730) to maintain brand cohesion.
*   **Don't** use sharp 90-degree corners. Even "square" elements should have a `sm` (0.25rem) radius to maintain the "Soft Minimalist" approachable feel.
*   **Don't** use "Drop Shadows" on every card. Rely on the "No-Line" background shifts for 90% of the UI hierarchy.